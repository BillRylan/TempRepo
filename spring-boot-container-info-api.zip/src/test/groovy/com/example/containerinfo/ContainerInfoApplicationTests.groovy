package com.example.containerinfo

import com.example.containerinfo.service.ContainerParseService
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ContainerInfoApplicationTests {

    @Autowired
    ContainerParseService parseService

    @Test
    void testContainerParsing() {
        def testDoc = '''Name:         data-service-redis-cluster-0
Namespace:    gpa-app-dev
Priority:     0
Controlled By:  StatefulSet/data-service-redis-cluster
Init Containers:
vault-agent-init:
  Container ID:  containerd://5616b328111078f48v994b431f04be31edf68e5dEe130c4d04f87dfdfb324cf7
  Restart Count:  0
  Limits:
    cpu:     0.5
    memory:  128M
  Requests:
    cpu:     250m
    memory:  64Mi
Containers:
redis-cluster:
  Container ID:  containerd://3ce84dfe30265143ecda68a632f305ed7a9b289d84202ed137b93d610e2e959d
  Restart Count:  0
  Limits:
    cpu:     500m
    memory:  0.5Gi
  Requests:
    cpu:     0.1
    memory:  128M
vault-agent:
  Container ID:  containerd://2219724029c2ef27e07753afcdb11596cd1f52f4791e658877878bcba03c
  Restart Count:  4
  Limits:
    cpu:     1
    memory:  128Mi
  Requests:
    cpu:     250m
    memory:  64M'''

        def result = parseService.parse(testDoc)
        assert result.name == "data-service-redis-cluster-0"
        assert result.namespace == "gpa-app-dev"
        assert result.containers.size() == 3
        
        // 可以添加更多断言来验证解析结果
        println "测试解析结果: ${result}"
    }
}
    