package com.example.containerinfo.service

import com.example.containerinfo.model.Container
import com.example.containerinfo.model.PodInfo
import org.springframework.stereotype.Service

@Service
class ContainerParseService {

    PodInfo parse(String podDescription) {
        // 提取Pod基本信息
        String name = extractValue(podDescription, /(?m)^Name:\s+(\S+)/)
        String namespace = extractValue(podDescription, /(?m)^Namespace:\s+(\S+)/)

        // 提取并解析所有容器信息
        List<Container> containers = []
        
        // 解析Init Containers
        containers.addAll(parseContainers(
            podDescription, 
            /(?sm)^Init Containers:\n((?:.|\n)+?)(?=^Containers:|^Conditions:|$)/
        ))
        
        // 解析Containers
        containers.addAll(parseContainers(
            podDescription, 
            /(?sm)^Containers:\n((?:.|\n)+?)(?=^Conditions:|$)/
        ))

        return new PodInfo(
            name: name,
            namespace: namespace,
            containers: containers
        )
    }

    private List<Container> parseContainers(String content, String sectionPattern) {
        def containers = []
        def sectionMatcher = content =~ sectionPattern
        
        if (sectionMatcher.matches()) {
            String sectionContent = sectionMatcher[0][1]
            def containerMatcher = sectionContent =~ /(?m)^(\S+):\n\s+Container ID:\s+(\S+)\n\s+Restart Count:.*?\n\s+Limits:\n\s+cpu:\s+(\S+)\n\s+memory:\s+(\S+)\n\s+Requests:\n\s+cpu:\s+(\S+)\n\s+memory:\s+(\S+)/
            
            containerMatcher.each { match, name, id, limitCpu, limitMem, reqCpu, reqMem ->
                containers << new Container(
                    name: name,
                    id: id,
                    limits: [
                        cpu: unifyCpuUnit(limitCpu),
                        memory: unifyMemoryUnit(limitMem)
                    ],
                    requests: [
                        cpu: unifyCpuUnit(reqCpu),
                        memory: unifyMemoryUnit(reqMem)
                    ]
                )
            }
        }
        
        return containers
    }

    private String extractValue(String content, String pattern) {
        def matcher = content =~ pattern
        return matcher.matches() ? matcher[0][1] : ""
    }

    // 统一CPU单位为m
    private String unifyCpuUnit(String cpuValue) {
        if (cpuValue.endsWith('m')) {
            return cpuValue
        }
        
        try {
            def value = cpuValue.toDouble()
            return "${(value * 1000).toInteger()}m"
        } catch (Exception e) {
            return cpuValue
        }
    }

    // 统一内存单位为Mi
    private String unifyMemoryUnit(String memoryValue) {
        if (memoryValue.endsWith('Mi')) {
            return memoryValue
        }
        
        def unitFactors = [
            'M': 1,
            'Gi': 1024,
            'G': 1024,
            'Ki': 0.0009765625,
            'K': 0.0009765625
        ]
        
        def matcher = (memoryValue =~ /(\d+(\.\d+)?)(\D+)?/)
        if (matcher.matches()) {
            def value = matcher[0][1].toDouble()
            def unit = matcher[0][3] ?: 'M'
            
            if (unitFactors.containsKey(unit)) {
                def miValue = value * unitFactors[unit]
                return "${miValue.toInteger()}Mi"
            }
        }
        
        return memoryValue
    }
}
    