package com.example.containerinfo.controller

import com.example.containerinfo.model.Container
import com.example.containerinfo.model.PodInfo
import com.example.containerinfo.service.ContainerParseService
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/v1/containers")
class ContainerParseController {

    private final ContainerParseService parseService

    ContainerParseController(ContainerParseService parseService) {
        this.parseService = parseService
    }

    @CrossOrigin(origins = "*") // 允许所有来源的跨域请求，方便前端调试
    @PostMapping("/parse")
    ResponseEntity<PodInfo> parseContainerInfo(@RequestBody String podDescription) {
        try {
            PodInfo podInfo = parseService.parse(podDescription)
            return ResponseEntity.ok(podInfo)
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(null)
        }
    }
}
    