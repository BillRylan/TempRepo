package com.example.containerinfo

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class ContainerInfoApplication {
    static void main(String[] args) {
        SpringApplication.run(ContainerInfoApplication, args)
    }
}
    