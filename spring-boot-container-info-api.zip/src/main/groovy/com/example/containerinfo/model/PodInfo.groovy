package com.example.containerinfo.model

import groovy.transform.Immutable

@Immutable
class PodInfo {
    String name
    String namespace
    List<Container> containers
}
    