package com.example.containerinfo.model

import groovy.transform.Immutable

@Immutable
class Container {
    String name
    String id
    Map<String, String> limits
    Map<String, String> requests
}
    